from flask import Flask, render_template, jsonify, request
import random
import certifi
import os
from datetime import datetime, timedelta
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
import pytz
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__, static_folder='static', static_url_path='/static')

# MongoDB Atlas Connection (loaded from .env file for security)
MONGO_URI = os.getenv('MONGO_URI')
DB_NAME = os.getenv('DB_NAME', 'light_sensor_db')

if not MONGO_URI:
    print("⚠️ MONGO_URI not found in .env file")
    db = None
    usage_collection = None
    room_collections = {}
else:
    try:
        client = MongoClient(
            MONGO_URI, 
            serverSelectionTimeoutMS=10000,
            tlsCAFile=certifi.where(),
            tls=True
        )
        client.admin.command('ping')
        db = client[DB_NAME]
        usage_collection = db['daily_usage']
        
        # Room-specific collections
        room_collections = {
            'living': db['room_living'],
            'bedroom': db['room_bedroom'],
            'kitchen': db['room_kitchen'],
            'bathroom': db['room_bathroom'],
            'office': db['room_office'],
            'garage': db['room_garage']
        }
        
        print("✅ Connected to MongoDB Atlas")
        print("📦 Room collections: living, bedroom, kitchen, bathroom, office, garage")
    except ConnectionFailure as e:
        print(f"⚠️ MongoDB not available. Error: {e}")
        db = None
        usage_collection = None
        room_collections = {}
    except Exception as e:
        print(f"⚠️ MongoDB connection error: {e}")
        db = None
        usage_collection = None
        room_collections = {}

# Simulated sensor data storage
sensor_history = []

def generate_sensor_reading():
    """Simulate a light sensor reading (0-50 lux)"""
    hour = datetime.now().hour
    if 6 <= hour <= 18:
        base = 25 + (15 * (1 - abs(hour - 12) / 6))
    else:
        base = 10
    noise = random.gauss(0, 5)
    return max(0, min(50, base + noise))

def get_sensor_status(lux):
    """Determine status based on light level"""
    if lux < 15:
        return {"level": "Dark", "color": "#1a1a2e", "icon": "🌙"}
    elif lux < 25:
        return {"level": "Dim", "color": "#16213e", "icon": "🌆"}
    elif lux < 35:
        return {"level": "Normal", "color": "#e94560", "icon": "☀️"}
    elif lux < 50:
        return {"level": "Bright", "color": "#f39c12", "icon": "🌞"}
    else:
        return {"level": "Very Bright", "color": "#f1c40f", "icon": "⚡"}

@app.route('/')
def dashboard():
    return render_template('dashboard.html')

@app.route('/api/sensor')
def get_sensor_data():
    """Get current sensor reading"""
    lux = generate_sensor_reading()
    status = get_sensor_status(lux)
    timestamp = datetime.now().isoformat()
    
    reading = {
        "lux": round(lux, 1),
        "timestamp": timestamp,
        "status": status
    }
    
    sensor_history.append(reading)
    if len(sensor_history) > 50:
        sensor_history.pop(0)
    
    return jsonify(reading)

@app.route('/api/history')
def get_history():
    return jsonify(sensor_history)

@app.route('/api/stats')
def get_stats():
    if not sensor_history:
        return jsonify({"avg": 0, "min": 0, "max": 0, "readings": 0})
    
    lux_values = [r["lux"] for r in sensor_history]
    return jsonify({
        "avg": round(sum(lux_values) / len(lux_values), 1),
        "min": round(min(lux_values), 1),
        "max": round(max(lux_values), 1),
        "readings": len(sensor_history)
    })

# ===== MongoDB Usage API =====

@app.route('/api/usage/reset', methods=['POST'])
def reset_usage():
    """Reset all usage data"""
    if usage_collection is not None:
        usage_collection.delete_many({})
        return jsonify({"success": True, "message": "All data cleared"})
    return jsonify({"success": False, "message": "MongoDB not available"})

@app.route('/api/usage/save', methods=['POST'])
def save_usage():
    """Save daily usage data"""
    data = request.json
    
    if not data or 'date' not in data:
        return jsonify({"error": "Invalid data"}), 400
    
    usage_data = {
        "date": data['date'],
        "onSeconds": data.get('onSeconds', 0),
        "offSeconds": 86400 - data.get('onSeconds', 0),
        "updatedAt": datetime.now().isoformat()
    }
    
    if usage_collection is not None:
        usage_collection.update_one(
            {"date": data['date']},
            {"$set": usage_data},
            upsert=True
        )
        return jsonify({"success": True})
    return jsonify({"success": False, "message": "MongoDB not available"})

@app.route('/api/usage/<date>')
def get_usage(date):
    """Get usage for a specific date"""
    if usage_collection is not None:
        record = usage_collection.find_one({"date": date})
        if record:
            return jsonify({
                "date": record['date'],
                "onSeconds": record.get('onSeconds', 0),
                "offSeconds": record.get('offSeconds', 0)
            })
    return jsonify({"date": date, "onSeconds": 0, "offSeconds": 86400})

@app.route('/api/usage/statistics')
def get_usage_statistics():
    """Get weekly and monthly statistics EXCLUDING today (today is tracked live in frontend)"""
    # Use PST timezone to match frontend
    pst = pytz.timezone('America/Los_Angeles')
    today = datetime.now(pst)
    today_str = today.strftime('%Y-%m-%d')
    
    # Calculate week start as SUNDAY (Python weekday: Mon=0, Sun=6)
    # So days since Sunday = (weekday + 1) % 7
    days_since_sunday = (today.weekday() + 1) % 7
    week_start = today - timedelta(days=days_since_sunday)
    week_start_str = week_start.strftime('%Y-%m-%d')
    month_start_str = today.strftime('%Y-%m-01')
    
    weekly_seconds = 0
    monthly_seconds = 0
    
    if usage_collection is not None:
        # This week EXCLUDING today (frontend adds live dailySeconds)
        week_records = list(usage_collection.find({
            "date": {"$gte": week_start_str, "$lt": today_str}
        }))
        weekly_seconds = sum(r.get('onSeconds', 0) for r in week_records)
        
        # This month EXCLUDING today (frontend adds live dailySeconds)
        month_records = list(usage_collection.find({
            "date": {"$gte": month_start_str, "$lt": today_str}
        }))
        monthly_seconds = sum(r.get('onSeconds', 0) for r in month_records)
    
    return jsonify({
        "daily": 0,  # Not used - frontend tracks today live
        "weekly": weekly_seconds,
        "monthly": monthly_seconds
    })

# ===== Room-Specific Usage API =====

VALID_ROOMS = ['living', 'bedroom', 'kitchen', 'bathroom', 'office', 'garage']

@app.route('/api/room/<room_name>/save', methods=['POST'])
def save_room_usage(room_name):
    """Save daily usage data for a specific room"""
    if room_name not in VALID_ROOMS:
        return jsonify({"error": f"Invalid room. Valid rooms: {VALID_ROOMS}"}), 400
    
    data = request.json
    if not data or 'date' not in data:
        return jsonify({"error": "Invalid data"}), 400
    
    room_data = {
        "date": data['date'],
        "onSeconds": data.get('onSeconds', 0),
        "avgLux": data.get('avgLux', 0),
        "updatedAt": datetime.now().isoformat()
    }
    
    if room_name in room_collections and room_collections[room_name] is not None:
        room_collections[room_name].update_one(
            {"date": data['date']},
            {"$set": room_data},
            upsert=True
        )
        return jsonify({"success": True, "room": room_name})
    return jsonify({"success": False, "message": "MongoDB not available"})

@app.route('/api/room/<room_name>/<date>')
def get_room_usage(room_name, date):
    """Get usage for a specific room on a specific date"""
    if room_name not in VALID_ROOMS:
        return jsonify({"error": f"Invalid room. Valid rooms: {VALID_ROOMS}"}), 400
    
    if room_name in room_collections and room_collections[room_name] is not None:
        record = room_collections[room_name].find_one({"date": date})
        if record:
            return jsonify({
                "room": room_name,
                "date": record['date'],
                "onSeconds": record.get('onSeconds', 0),
                "avgLux": record.get('avgLux', 0)
            })
    return jsonify({"room": room_name, "date": date, "onSeconds": 0, "avgLux": 0})

@app.route('/api/room/<room_name>/statistics')
def get_room_statistics(room_name):
    """Get weekly and monthly statistics for a specific room"""
    if room_name not in VALID_ROOMS:
        return jsonify({"error": f"Invalid room. Valid rooms: {VALID_ROOMS}"}), 400
    
    pst = pytz.timezone('America/Los_Angeles')
    today = datetime.now(pst)
    today_str = today.strftime('%Y-%m-%d')
    
    weekday = today.weekday()
    week_start = today - timedelta(days=weekday)
    week_start_str = week_start.strftime('%Y-%m-%d')
    month_start_str = today.strftime('%Y-%m-01')
    
    weekly_seconds = 0
    monthly_seconds = 0
    
    if room_name in room_collections and room_collections[room_name] is not None:
        # This week excluding today
        week_records = list(room_collections[room_name].find({
            "date": {"$gte": week_start_str, "$lt": today_str}
        }))
        weekly_seconds = sum(r.get('onSeconds', 0) for r in week_records)
        
        # This month excluding today
        month_records = list(room_collections[room_name].find({
            "date": {"$gte": month_start_str, "$lt": today_str}
        }))
        monthly_seconds = sum(r.get('onSeconds', 0) for r in month_records)
    
    return jsonify({
        "room": room_name,
        "weekly": weekly_seconds,
        "monthly": monthly_seconds
    })

@app.route('/api/rooms/all/<date>')
def get_all_rooms_usage(date):
    """Get usage for all rooms on a specific date"""
    result = {}
    for room_name in VALID_ROOMS:
        if room_name in room_collections and room_collections[room_name] is not None:
            record = room_collections[room_name].find_one({"date": date})
            if record:
                result[room_name] = {
                    "onSeconds": record.get('onSeconds', 0),
                    "avgLux": record.get('avgLux', 0)
                }
            else:
                result[room_name] = {"onSeconds": 0, "avgLux": 0}
        else:
            result[room_name] = {"onSeconds": 0, "avgLux": 0}
    return jsonify({"date": date, "rooms": result})

@app.route('/api/rooms/reset', methods=['POST'])
def reset_all_rooms():
    """Reset all room usage data"""
    for room_name in VALID_ROOMS:
        if room_name in room_collections and room_collections[room_name] is not None:
            room_collections[room_name].delete_many({})
    return jsonify({"success": True, "message": "All room data cleared"})

if __name__ == '__main__':
    for i in range(20):
        lux = generate_sensor_reading()
        sensor_history.append({
            "lux": round(lux, 1),
            "timestamp": (datetime.now() - timedelta(seconds=(20-i)*3)).isoformat(),
            "status": get_sensor_status(lux)
        })
    
    app.run(debug=True, port=5001)
